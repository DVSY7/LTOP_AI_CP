# cathodic_rl/config/settings.py - 파일경로

"""전기방식 강화학습 환경에서 사용하는 공통 설정값."""

# ============================================================
# 정류기 출력 설정
# ============================================================

# 정류기 출력전압의 최소값과 최대값 [V]
MIN_OUTPUT_VOLTAGE: float = 0.0
MAX_OUTPUT_VOLTAGE: float = 60.0

# 강화학습 에이전트가 한 번의 행동으로 변경하는 전압 [V]
VOLTAGE_STEP: float = 0.5

# 환경 초기화 시 사용할 출력전압 [V]
INITIAL_OUTPUT_VOLTAGE: float = 10.0


# ============================================================
# 출력전류 설정
# ============================================================

# 정류기 출력전류 범위 [A]
MIN_OUTPUT_CURRENT: float = 0.0
MAX_OUTPUT_CURRENT: float = 30.0

# 환경 초기화 시 사용할 출력전류 [A]
INITIAL_OUTPUT_CURRENT: float = 1.0

# 임시 시뮬레이션용 전류 계산 계수 [A/V]
# 실제 물리모델이 아닌 프로그램 흐름 검증용 값
TEMP_CURRENT_PER_VOLT: float = 0.1


# ============================================================
# 방식전위 설정
# ============================================================

# 시뮬레이션에서 허용하는 방식전위 범위 [mV]
MIN_PIPE_POTENTIAL: float = -3000.0
MAX_PIPE_POTENTIAL: float = 0.0

# 임시 시뮬레이션용 방식전위 반응 계수 [mV/V]
# 출력전압이 증가하면 방식전위가 음의 방향으로 이동한다고 가정
TEMP_POTENTIAL_CHANGE_PER_VOLT: float = -20.0

# 목표 방식전위 구간 [mV]
#
# 주의:
# 아래 값은 현재 프로토타입용 임시값이다.
# 실제 적용 시 회사 기준, 현장 기준전극 종류,
# 관로 조건 및 관련 기준에 따라 반드시 수정해야 한다.
TARGET_POTENTIAL_MIN: float = -950.0
TARGET_POTENTIAL_MAX: float = -850.0

# 환경 초기화 시 사용할 방식전위 [mV]
INITIAL_PIPE_POTENTIAL: float = -700.0


# ============================================================
# 에피소드 설정
# ============================================================

# 한 에피소드에서 실행할 최대 제어 횟수
MAX_EPISODE_STEPS: int = 50


# ============================================================
# 행동 설정
# ============================================================

# DQN이 선택할 수 있는 이산 행동
ACTION_DECREASE: int = 0
ACTION_HOLD: int = 1
ACTION_INCREASE: int = 2

# 행동 번호와 실제 전압 변화량의 연결
ACTION_TO_DELTA_VOLTAGE: dict[int, float] = {
    ACTION_DECREASE: -VOLTAGE_STEP,
    ACTION_HOLD: 0.0,
    ACTION_INCREASE: VOLTAGE_STEP,
}

# ============================================================
# 재현성 설정
# ============================================================

# 난수 결과를 일정하게 재현하기 위한 기본 시드
DEFAULT_RANDOM_SEED: int = 42

# ============================================================
# DQN 학습 설정
# ============================================================

# 1차 프로토타입 학습 횟수
TOTAL_TRAINING_STEPS: int = 150_000

# 학습된 모델 저장 경로
DQN_MODEL_PATH: str = "models/trained/cathodic_dqn"
SAC_MODEL_PATH: str = "models/trained/cathodic_sac"

# 사용할 학습모델(알고리즘) 선택
RL_ALGORITHM: str = "sac"
